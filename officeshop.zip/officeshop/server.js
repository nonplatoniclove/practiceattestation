// Сервер магазина оргтехники. Без внешних зависимостей: только встроенные модули Node.js.
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const DATA = path.join(__dirname, 'data');
const PUBLIC = path.join(__dirname, 'public');

const readJSON = (f, d) => {
  try { return JSON.parse(fs.readFileSync(path.join(DATA, f), 'utf8')); } catch { return d; }
};
const writeJSON = (f, v) => fs.writeFileSync(path.join(DATA, f), JSON.stringify(v, null, 2));

const sessions = new Map(); // token -> email

const hash = (pass, salt) => crypto.scryptSync(pass, salt, 32).toString('hex');

const send = (res, code, obj) => {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
};

const body = req => new Promise(resolve => {
  let s = '';
  req.on('data', c => { s += c; if (s.length > 1e6) req.destroy(); });
  req.on('end', () => { try { resolve(JSON.parse(s || '{}')); } catch { resolve({}); } });
});

const auth = req => {
  const t = (req.headers.authorization || '').replace('Bearer ', '');
  const email = sessions.get(t);
  if (!email) return null;
  return readJSON('users.json', []).find(u => u.email === email) || null;
};

const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript' };

async function api(req, res, url) {
  const route = req.method + ' ' + url.pathname;

  if (route === 'GET /api/products') {
    // Серверная фильтрация: category, brand, min, max, q, sort
    const q = url.searchParams;
    let list = readJSON('products.json', []);
    if (q.get('category')) list = list.filter(p => p.category === q.get('category'));
    if (q.get('brand')) list = list.filter(p => p.brand === q.get('brand'));
    if (q.get('min')) list = list.filter(p => p.price >= +q.get('min'));
    if (q.get('max')) list = list.filter(p => p.price <= +q.get('max'));
    if (q.get('q')) list = list.filter(p => p.name.toLowerCase().includes(q.get('q').toLowerCase()));
    if (q.get('sort') === 'asc') list.sort((a, b) => a.price - b.price);
    if (q.get('sort') === 'desc') list.sort((a, b) => b.price - a.price);
    return send(res, 200, list);
  }

  if (route === 'POST /api/register') {
    const { name, email, password } = await body(req);
    if (!name || !/^\S+@\S+\.\S+$/.test(email || '') || (password || '').length < 6)
      return send(res, 400, { error: 'Проверьте имя, email и пароль (минимум 6 символов)' });
    const users = readJSON('users.json', []);
    if (users.some(u => u.email === email)) return send(res, 409, { error: 'Email уже зарегистрирован' });
    const salt = crypto.randomBytes(8).toString('hex');
    users.push({ name, email, salt, hash: hash(password, salt) });
    writeJSON('users.json', users);
    return send(res, 201, { ok: true });
  }

  if (route === 'POST /api/login') {
    const { email, password } = await body(req);
    const u = readJSON('users.json', []).find(u => u.email === email);
    if (!u || u.hash !== hash(password || '', u.salt)) return send(res, 401, { error: 'Неверный email или пароль' });
    const token = crypto.randomBytes(16).toString('hex');
    sessions.set(token, u.email);
    return send(res, 200, { token, name: u.name, email: u.email });
  }

  if (route === 'POST /api/orders') {
    const user = auth(req);
    if (!user) return send(res, 401, { error: 'Требуется вход в аккаунт' });
    const { items, address, phone } = await body(req);
    if (!Array.isArray(items) || !items.length) return send(res, 400, { error: 'Корзина пуста' });
    if (!address || !/^[\d+\s()-]{10,}$/.test(phone || '')) return send(res, 400, { error: 'Укажите адрес и корректный телефон' });
    const products = readJSON('products.json', []);
    // Цену считаем на сервере, а не берём из клиента
    let total = 0; const lines = [];
    for (const it of items) {
      const p = products.find(x => x.id === it.id);
      if (!p || !(it.qty > 0)) return send(res, 400, { error: 'Некорректная позиция заказа' });
      total += p.price * it.qty;
      lines.push({ id: p.id, name: p.name, price: p.price, qty: it.qty });
    }
    const orders = readJSON('orders.json', []);
    const order = { id: orders.length + 1, email: user.email, items: lines, total, address, phone, date: new Date().toISOString() };
    orders.push(order);
    writeJSON('orders.json', orders);
    return send(res, 201, order);
  }

  if (route === 'GET /api/orders') {
    const user = auth(req);
    if (!user) return send(res, 401, { error: 'Требуется вход в аккаунт' });
    return send(res, 200, readJSON('orders.json', []).filter(o => o.email === user.email));
  }

  send(res, 404, { error: 'Не найдено' });
}

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname.startsWith('/api/')) return api(req, res, url).catch(() => send(res, 500, { error: 'Ошибка сервера' }));
  const file = path.join(PUBLIC, url.pathname === '/' ? 'index.html' : url.pathname);
  if (!file.startsWith(PUBLIC) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    res.writeHead(404); return res.end('Not found');
  }
  res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream' });
  fs.createReadStream(file).pipe(res);
}).listen(PORT, () => console.log('Магазин запущен: http://localhost:' + PORT));
