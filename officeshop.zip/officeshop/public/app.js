const $ = id => document.getElementById(id);
const fmt = n => n.toLocaleString('ru-RU');
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// ---------- Состояние ----------
let cart = JSON.parse(localStorage.getItem('cart') || '[]'); // [{id,name,price,qty}]
let user = JSON.parse(localStorage.getItem('user') || 'null'); // {token,name,email}
let isReg = false;

const saveCart = () => { localStorage.setItem('cart', JSON.stringify(cart)); renderCart(); };

async function api(url, opts = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (user) headers.Authorization = 'Bearer ' + user.token;
  const r = await fetch(url, { ...opts, headers });
  const data = await r.json();
  if (!r.ok) throw new Error(data.error || 'Ошибка');
  return data;
}

function toast(t) {
  $('toast').textContent = t; $('toast').classList.add('show');
  setTimeout(() => $('toast').classList.remove('show'), 2000);
}

// ---------- Навигация ----------
function go(id) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  $(id).classList.add('active');
  if (id === 'account') renderAccount();
  if (id === 'checkout') $('oTotal').textContent = fmt(total());
}
document.querySelectorAll('[data-go]').forEach(b => b.onclick = () => go(b.dataset.go));

// ---------- Каталог и фильтры ----------
let allProducts = [];
async function initFilters() {
  allProducts = await api('/api/products');
  const fill = (sel, key) => [...new Set(allProducts.map(p => p[key]))].sort()
    .forEach(v => sel.insertAdjacentHTML('beforeend', `<option>${esc(v)}</option>`));
  fill($('fCat'), 'category'); fill($('fBrand'), 'brand');
}
async function loadProducts() {
  const q = new URLSearchParams();
  [['q', 'fQ'], ['category', 'fCat'], ['brand', 'fBrand'], ['min', 'fMin'], ['max', 'fMax'], ['sort', 'fSort']]
    .forEach(([k, id]) => { if ($(id).value) q.set(k, $(id).value); });
  const list = await api('/api/products?' + q);
  $('found').textContent = `(найдено: ${list.length})`;
  $('products').innerHTML = list.length ? list.map(p => `
    <article class="card">
      <div class="img" aria-hidden="true">🖨️</div>
      <h3>${esc(p.name)}</h3>
      <small>${esc(p.category)} · ${esc(p.brand)}</small>
      <div class="price">${fmt(p.price)} ₽</div>
      <button onclick="addToCart(${p.id})">В корзину</button>
    </article>`).join('') : '<p>Ничего не найдено. Измените фильтры.</p>';
}
['fQ', 'fCat', 'fBrand', 'fMin', 'fMax', 'fSort'].forEach(id => $(id).addEventListener('input', loadProducts));
$('fReset').onclick = () => {
  ['fQ', 'fCat', 'fBrand', 'fMin', 'fMax', 'fSort'].forEach(id => $(id).value = '');
  loadProducts();
};

// ---------- Корзина ----------
const total = () => cart.reduce((s, i) => s + i.price * i.qty, 0);

function addToCart(id) {
  const p = allProducts.find(x => x.id === id);
  const it = cart.find(x => x.id === id);
  if (it) it.qty++; else cart.push({ id: p.id, name: p.name, price: p.price, qty: 1 });
  saveCart(); toast('Добавлено в корзину');
}
function changeQty(id, d) {
  const it = cart.find(x => x.id === id);
  it.qty += d;
  if (it.qty <= 0) cart = cart.filter(x => x.id !== id);
  saveCart();
}
function renderCart() {
  $('cartCount').textContent = cart.reduce((s, i) => s + i.qty, 0);
  if (!cart.length) { $('cartBox').innerHTML = '<p>Корзина пуста. Выберите товары в каталоге.</p>'; return; }
  $('cartBox').innerHTML = `<table>
    <tr><th>Товар</th><th>Цена</th><th>Кол-во</th><th>Сумма</th></tr>
    ${cart.map(i => `<tr><td>${esc(i.name)}</td><td>${fmt(i.price)} ₽</td>
      <td class="qty"><button onclick="changeQty(${i.id},-1)" aria-label="Меньше">−</button> ${i.qty}
      <button onclick="changeQty(${i.id},1)" aria-label="Больше">+</button></td>
      <td>${fmt(i.price * i.qty)} ₽</td></tr>`).join('')}
    </table>
    <p><b>Итого: ${fmt(total())} ₽</b></p>
    <button onclick="go('checkout')">Оформить заказ</button>`;
}

// ---------- Оформление заказа ----------
$('orderForm').onsubmit = async e => {
  e.preventDefault();
  if (!user) { go('account'); $('aMsg').textContent = 'Войдите, чтобы оформить заказ'; return; }
  try {
    const o = await api('/api/orders', { method: 'POST', body: JSON.stringify({
      items: cart.map(i => ({ id: i.id, qty: i.qty })), address: $('oAddr').value, phone: $('oPhone').value }) });
    cart = []; saveCart();
    $('oMsg').className = 'msg ok'; $('oMsg').textContent = `Заказ №${o.id} оформлен на ${fmt(o.total)} ₽`;
    $('orderForm').reset();
  } catch (err) { $('oMsg').className = 'msg'; $('oMsg').textContent = err.message; }
};

// ---------- Личный кабинет ----------
async function renderAccount() {
  $('authBox').hidden = !!user; $('profileBox').hidden = !user;
  if (!user) return;
  $('uName').textContent = user.name;
  try {
    const orders = await api('/api/orders');
    $('orders').innerHTML = orders.length ? orders.map(o => `<div class="box" style="margin-bottom:10px">
      <b>Заказ №${o.id}</b> от ${new Date(o.date).toLocaleDateString('ru-RU')}<br>
      ${o.items.map(i => `${esc(i.name)} × ${i.qty}`).join('<br>')}<br><b>Итого: ${fmt(o.total)} ₽</b></div>`).join('')
      : '<p>Заказов пока нет.</p>';
  } catch { user = null; localStorage.removeItem('user'); renderAccount(); }
}
$('aToggle').onclick = () => {
  isReg = !isReg;
  $('authTitle').textContent = isReg ? 'Регистрация' : 'Вход';
  $('aBtn').textContent = isReg ? 'Зарегистрироваться' : 'Войти';
  $('nameRow').hidden = !isReg;
  $('aToggle').textContent = isReg ? 'Уже есть аккаунт? Войти' : 'Нет аккаунта? Регистрация';
  $('aMsg').textContent = '';
};
$('authForm').onsubmit = async e => {
  e.preventDefault();
  const email = $('aEmail').value.trim(), password = $('aPass').value;
  try {
    if (isReg) {
      await api('/api/register', { method: 'POST', body: JSON.stringify({ name: $('aName').value.trim(), email, password }) });
      $('aToggle').click(); $('aMsg').className = 'msg ok'; $('aMsg').textContent = 'Готово! Теперь войдите';
    } else {
      user = await api('/api/login', { method: 'POST', body: JSON.stringify({ email, password }) });
      localStorage.setItem('user', JSON.stringify(user)); renderAccount(); toast('Вы вошли в аккаунт');
    }
  } catch (err) { $('aMsg').className = 'msg'; $('aMsg').textContent = err.message; }
};
$('logout').onclick = () => { user = null; localStorage.removeItem('user'); renderAccount(); };

// ---------- Старт ----------
initFilters().then(loadProducts);
renderCart();
